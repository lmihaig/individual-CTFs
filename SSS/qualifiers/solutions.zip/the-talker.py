import socket
s = socket.socket(socket.AF_INET,  socket.SOCK_DGRAM)
s.bind(('127.0.0.1', 4444))
while True:
  msg, addr = s.recvfrom(1024)
  if len(msg) > 0:
    print msg
    break